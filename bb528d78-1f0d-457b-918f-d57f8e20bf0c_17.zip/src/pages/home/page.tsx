
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-orange-50 flex flex-col">
      <div className="flex-1 flex flex-col justify-center px-6 py-8 lg:px-12 lg:py-16">
        {/* Header Section */}
        <div className={`text-center mb-8 lg:mb-12 transition-all duration-1000 ${
          isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-8'
        }`}>
          <h1 className="text-4xl lg:text-6xl xl:text-7xl font-bold text-pink-600 mb-4 lg:mb-6" style={{ fontFamily: 'Pacifico, serif' }}>
            Academia de Pastelería
          </h1>
          <p className="text-pink-500 text-lg lg:text-2xl xl:text-3xl mb-3 lg:mb-4">Aprende el Arte de la Repostería</p>
          <p className="text-gray-600 max-w-md lg:max-w-2xl xl:max-w-3xl mx-auto text-sm lg:text-lg xl:text-xl">
            Descubre los secretos de la pastelería profesional y crea deliciosos postres
          </p>
        </div>

        {/* Image Section - Responsive sizing */}
        <div className={`flex-1 flex items-center justify-center mb-8 lg:mb-12 transition-all duration-1000 delay-300 ${
          isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
        }`}>
          <div className="w-full max-w-sm lg:max-w-md xl:max-w-lg h-64 lg:h-80 xl:h-96 rounded-2xl lg:rounded-3xl overflow-hidden shadow-lg lg:shadow-2xl hover:shadow-3xl hover:scale-105 transition-all duration-300">
            <img 
              src="https://static.readdy.ai/image/76fe4ab091387bca5952e550b23bc124/a6a352d4897cfc30308e9662d13295fb.jpeg"
              alt="Academia de Pastelería"
              className="w-full h-full object-cover object-center"
            />
          </div>
        </div>

        {/* Button and Text Section */}
        <div className={`text-center space-y-4 lg:space-y-6 transition-all duration-1000 delay-500 ${
          isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <Link 
            to="/registro"
            className="inline-block bg-gradient-to-r from-pink-500 to-orange-400 text-white font-semibold py-4 lg:py-6 px-8 lg:px-12 rounded-2xl lg:rounded-3xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 text-base lg:text-xl xl:text-2xl group"
          >
            <div className="flex items-center">
              <i className="ri-calendar-check-line mr-3 text-xl lg:text-2xl xl:text-3xl group-hover:animate-pulse"></i>
              Ingresa Aquí para Reservar tu Lugar
            </div>
          </Link>

          <p className="text-gray-500 text-sm lg:text-lg xl:text-xl max-w-xs lg:max-w-md xl:max-w-lg mx-auto">
            Únete a nuestras clases gratuitas para convertirte en un pastelero profesional
          </p>
        </div>
      </div>
    </div>
  );
}
