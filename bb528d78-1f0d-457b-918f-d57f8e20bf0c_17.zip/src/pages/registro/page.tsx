
import { useState, useEffect } from 'react';

export default function Registro() {
  const [formData, setFormData] = useState({
    nombre: '',
    apellido: '',
    telefono: '',
    email: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('');

    try {
      // Crear FormData con la codificación correcta
      const formDataToSend = new URLSearchParams();
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSend.append(key, value);
      });

      const response = await fetch('https://readdy.ai/api/form/d3p9m3snmar9en36n7sg', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formDataToSend
      });

      if (response.ok) {
        setSubmitStatus('¡Registro exitoso! Redirigiendo a WhatsApp...');
        
        // Limpiar el formulario
        setFormData({
          nombre: '',
          apellido: '',
          telefono: '',
          email: ''
        });
        
        // Esperar un momento y redirigir a WhatsApp
        setTimeout(() => {
          window.open('https://chat.whatsapp.com/HI2KD6SkYUv08axwnp2ur5', '_blank');
          setSubmitStatus('¡Perfecto! Ya puedes unirte al grupo de WhatsApp.');
        }, 1500);
      } else {
        setSubmitStatus('Error al enviar el registro. Por favor intenta nuevamente.');
      }
    } catch (error) {
      console.error('Error:', error);
      setSubmitStatus('Error al enviar el registro. Por favor intenta nuevamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-orange-50 relative overflow-hidden">
      {/* Decorative background elements - Responsive positioning */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className={`absolute top-10 left-10 lg:top-20 lg:left-20 w-20 h-20 lg:w-32 lg:h-32 bg-pink-200/30 rounded-full blur-xl transition-all duration-1000 ${
          isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
        }`}></div>
        <div className={`absolute top-32 right-16 lg:top-40 lg:right-32 w-16 h-16 lg:w-24 lg:h-24 bg-orange-200/30 rounded-full blur-lg transition-all duration-1000 delay-200 ${
          isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
        }`}></div>
        <div className={`absolute bottom-20 left-20 lg:bottom-32 lg:left-40 w-24 h-24 lg:w-36 lg:h-36 bg-yellow-200/30 rounded-full blur-xl transition-all duration-1000 delay-400 ${
          isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
        }`}></div>
        <div className={`absolute bottom-40 right-10 lg:bottom-48 lg:right-20 w-18 h-18 lg:w-28 lg:h-28 bg-pink-300/30 rounded-full blur-lg transition-all duration-1000 delay-600 ${
          isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
        }`}></div>
      </div>

      <div className="flex flex-col lg:flex-row min-h-screen">
        {/* Left side - Header and Image (Desktop) / Top section (Mobile) */}
        <div className={`lg:w-1/2 lg:flex lg:flex-col lg:justify-center lg:items-center relative z-10 pt-8 pb-6 lg:px-12 transition-all duration-1000 ${
          isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
        }`}>
          <div className="text-center lg:text-left mb-6 lg:mb-8">
            <h1 className="text-3xl lg:text-5xl xl:text-6xl font-bold text-pink-600 mb-2 lg:mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
              Academia de Pastelería
            </h1>
            <p className="text-pink-500 text-sm lg:text-xl xl:text-2xl mb-4 lg:mb-6">Aprende el Arte de la Repostería</p>
          </div>
          
          {/* Hero image - Different sizes for mobile/desktop */}
          <div className="mx-auto lg:mx-0 w-80 lg:w-96 xl:w-[28rem] h-48 lg:h-64 xl:h-80 rounded-2xl lg:rounded-3xl overflow-hidden shadow-lg lg:shadow-2xl hover:shadow-3xl hover:scale-105 transition-all duration-300">
            <img 
              src="https://static.readdy.ai/image/76fe4ab091387bca5952e550b23bc124/a6a352d4897cfc30308e9662d13295fb.jpeg"
              alt="Academia de Pastelería"
              className="w-full h-full object-cover object-top"
            />
          </div>
        </div>

        {/* Right side - Registration Form */}
        <div className={`lg:w-1/2 lg:flex lg:items-center lg:justify-center relative z-10 px-6 pb-8 lg:px-12 transition-all duration-1000 delay-300 ${
          isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
        }`}>
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl lg:shadow-2xl p-6 lg:p-8 xl:p-10 mx-auto max-w-sm lg:max-w-md xl:max-w-lg w-full hover:shadow-3xl transition-all duration-300">
            <div className="text-center mb-6 lg:mb-8">
              <h2 className="text-2xl lg:text-3xl xl:text-4xl font-bold text-gray-800 mb-2 lg:mb-4">¡Únete a Nosotros!</h2>
              <p className="text-gray-600 text-sm lg:text-base xl:text-lg">Regístrate y forma parte de nuestra comunidad dulce</p>
            </div>

            <form onSubmit={handleSubmit} data-readdy-form id="registro-form" className="space-y-4 lg:space-y-6">
              <div className="grid grid-cols-2 gap-3 lg:gap-4">
                <div className="group">
                  <label className="block text-sm lg:text-base font-medium text-gray-700 mb-1 lg:mb-2">Nombre</label>
                  <input
                    type="text"
                    name="nombre"
                    value={formData.nombre}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 lg:px-4 py-2.5 lg:py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm lg:text-base focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition-all duration-200 hover:bg-gray-100"
                    placeholder="Tu nombre"
                  />
                </div>
                <div className="group">
                  <label className="block text-sm lg:text-base font-medium text-gray-700 mb-1 lg:mb-2">Apellido</label>
                  <input
                    type="text"
                    name="apellido"
                    value={formData.apellido}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 lg:px-4 py-2.5 lg:py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm lg:text-base focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition-all duration-200 hover:bg-gray-100"
                    placeholder="Tu apellido"
                  />
                </div>
              </div>

              <div className="group">
                <label className="block text-sm lg:text-base font-medium text-gray-700 mb-1 lg:mb-2">Teléfono</label>
                <input
                  type="tel"
                  name="telefono"
                  value={formData.telefono}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 lg:px-4 py-2.5 lg:py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm lg:text-base focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition-all duration-200 hover:bg-gray-100"
                  placeholder="+52 123 456 7890"
                />
              </div>

              <div className="group">
                <label className="block text-sm lg:text-base font-medium text-gray-700 mb-1 lg:mb-2">Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 lg:px-4 py-2.5 lg:py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm lg:text-base focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition-all duration-200 hover:bg-gray-100"
                  placeholder="tu@email.com"
                />
              </div>

              {submitStatus && (
                <div className={`p-3 lg:p-4 rounded-xl text-sm lg:text-base text-center transition-all duration-300 ${
                  submitStatus.includes('exitoso') || submitStatus.includes('Perfecto')
                    ? 'bg-green-100 text-green-700 animate-pulse' 
                    : 'bg-red-100 text-red-700'
                }`}>
                  {submitStatus}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-pink-500 to-orange-400 text-white font-semibold py-3 lg:py-4 px-6 lg:px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:transform-none text-base lg:text-lg group"
              >
                {isSubmitting ? (
                  <div className="flex items-center justify-center">
                    <i className="ri-loader-4-line animate-spin mr-2 lg:mr-3 text-lg lg:text-xl"></i>
                    Enviando registro...
                  </div>
                ) : (
                  <div className="flex items-center justify-center">
                    <i className="ri-whatsapp-line mr-2 lg:mr-3 text-lg lg:text-xl group-hover:animate-bounce"></i>
                    Reserva aquí tu lugar
                  </div>
                )}
              </button>
            </form>

            <div className="mt-6 lg:mt-8 text-center">
              <p className="text-xs lg:text-sm text-gray-500 mb-3 lg:mb-4">
                Al registrarte, serás dirigido a nuestro grupo de WhatsApp donde podrás:
              </p>
              <div className="flex flex-col lg:flex-row justify-center lg:space-x-6 space-y-2 lg:space-y-0 text-xs lg:text-sm text-gray-600">
                <span className="flex items-center justify-center lg:justify-start hover:text-pink-500 transition-colors duration-200">
                  <i className="ri-calendar-line mr-2 text-pink-500 text-sm lg:text-base"></i>
                  Horarios y fechas de las clases
                </span>
                <span className="flex items-center justify-center lg:justify-start hover:text-orange-500 transition-colors duration-200">
                  <i className="ri-book-open-line mr-2 text-orange-500 text-sm lg:text-base"></i>
                  Recetas
                </span>
                <span className="flex items-center justify-center lg:justify-start hover:text-yellow-500 transition-colors duration-200">
                  <i className="ri-shopping-bag-line mr-2 text-yellow-5

00 text-sm lg:text-base"></i>
                  Todo los materiales para cada clase
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating decorative elements - Responsive sizing */}
      <div className={`absolute bottom-4 left-4 lg:bottom-8 lg:left-8 w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center transition-all duration-1000 delay-800 hover:scale-110 ${
        isLoaded ? 'opacity-100 rotate-0' : 'opacity-0 -rotate-45'
      }`}>
        <i className="ri-cake-2-line text-2xl lg:text-3xl text-pink-300 hover:text-pink-500 transition-colors duration-200"></i>
      </div>
      <div className={`absolute bottom-4 right-4 lg:bottom-8 lg:right-8 w-12 h-12 lg:w-16 lg:h-16 flex items-center justify-center transition-all duration-1000 delay-1000 hover:scale-110 ${
        isLoaded ? 'opacity-100 rotate-0' : 'opacity-0 rotate-45'
      }`}>
        <i className="ri-heart-3-line text-2xl lg:text-3xl text-orange-300 hover:text-orange-500 transition-colors duration-200 hover:animate-pulse"></i>
      </div>
    </div>
  );
}
